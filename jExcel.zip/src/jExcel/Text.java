/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jExcel;

/**
 *
 * @author 130683X
 */
public class Text{
    private String value="";
    public Text(String value){
        this.value=value;
    }
    public void setValue(String value){
        this.value=value;
    }
    public String getValue(){
        return this.value;
    }
    public void echo(){
        System.out.println(value);
    }
}
