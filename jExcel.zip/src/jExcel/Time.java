/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jExcel;

/**
 *
 * @author 130683X
 */
public class Time extends Angle{
    public Time(int v2,int v1,double v0){
        super(v2,v1,v0);
        super.setSymbol(":");
        super.limit=60;
    }
}
