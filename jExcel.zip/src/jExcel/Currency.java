/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jExcel;

/**
 *
 * @author 130683X
 */
public class Currency extends Number {
    private String currencySymbol="$";
    
    public Currency(double value){
        super(value);
    }
    public void echo(){
        System.out.println(String.format( currencySymbol+" %."+String.valueOf(decimalPlaces)+"f",this.getValue() ));
    }
    public void setSymbol(String symbol){
        this.currencySymbol=symbol;
    }
    public String getSymbol(){
        return this.currencySymbol;
    }
}
