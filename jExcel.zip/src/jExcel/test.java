/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jExcel;

import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;
import javax.xml.bind.DatatypeConverter;

/**
 *
 * @author pro.info
 */
public class test {
    String name;
    int age;
    public static void main(String[] args) throws ParseException {
        System.out.println("bbcd(".matches(".*[:,=\\+\\-\\/\\(]$"));
    }
}
