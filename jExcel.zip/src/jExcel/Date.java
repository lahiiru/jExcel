/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jExcel;

/**
 *
 * @author pro.info
 */
public class Date{
    int year=1000;
    int month=1;
    int day=1;
    public void echo(){
        System.out.println(String.format(String.valueOf(year)+"/"+String.valueOf(month)+"/"+ String.valueOf(day)));
    }
}
